SMS Conductor Database Viewer - v1.1
====================================

QUICK START:
1. Simply double-click "SMSConductorDB_v1.1.exe"
2. No installation needed!
3. All credentials are embedded

NEW in v1.1:
- "Add to Reply Messages" feature
  * Go to "All Messages" tab
  * Right-click any OUTBOUND message
  * Select "Add to Reply Messages"
  * Start a follow-up conversation!

This is a single-file executable with everything bundled.
No extraction needed, just run the .exe file.

---
Version: 1.1
Release Date: November 10, 2025

